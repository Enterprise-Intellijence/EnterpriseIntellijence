--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE vinted;
--
-- Name: vinted; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE vinted WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Italian_Italy.1252';


ALTER DATABASE vinted OWNER TO postgres;

\connect vinted

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: clothing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clothing (
    colour character varying(255) NOT NULL,
    product_gender character varying(255) NOT NULL,
    product_id character varying(36) NOT NULL,
    size character varying(36) NOT NULL
);


ALTER TABLE public.clothing OWNER TO postgres;

--
-- Name: delivery; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery (
    id character varying(36) NOT NULL,
    delivered_time timestamp(6) without time zone,
    currency character varying(255),
    price double precision,
    delivery_status character varying(255) NOT NULL,
    send_time timestamp(6) without time zone NOT NULL,
    shipper character varying(255),
    receiver_address character varying(36) NOT NULL,
    sender_address character varying(36) NOT NULL
);


ALTER TABLE public.delivery OWNER TO postgres;

--
-- Name: delivery_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivery_address (
    id character varying(36) NOT NULL,
    city character varying(255) NOT NULL,
    country character varying(255) NOT NULL,
    header character varying(255) NOT NULL,
    is_default boolean NOT NULL,
    phone_number character varying(255) NOT NULL,
    street character varying(255) NOT NULL,
    zip_code character varying(255) NOT NULL,
    owner_address character varying(36) NOT NULL
);


ALTER TABLE public.delivery_address OWNER TO postgres;

--
-- Name: entertainment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entertainment (
    entertainment_language character varying(255) NOT NULL,
    product_id character varying(36) NOT NULL
);


ALTER TABLE public.entertainment OWNER TO postgres;

--
-- Name: followers_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.followers_list (
    id character varying(36) NOT NULL,
    following_from timestamp(6) without time zone,
    follower character varying(36) NOT NULL,
    following character varying(36) NOT NULL
);


ALTER TABLE public.followers_list OWNER TO postgres;

--
-- Name: home; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home (
    colour character varying(255) NOT NULL,
    home_material character varying(255) NOT NULL,
    product_id character varying(36) NOT NULL,
    size character varying(36) NOT NULL
);


ALTER TABLE public.home OWNER TO postgres;

--
-- Name: invalid_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invalid_tokens (
    id character varying(36) NOT NULL,
    expiration_date timestamp without time zone NOT NULL,
    token character varying(255) NOT NULL
);


ALTER TABLE public.invalid_tokens OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id character varying(36) NOT NULL,
    conversation_id character varying(36) NOT NULL,
    message_date timestamp(6) without time zone NOT NULL,
    message_status character varying(255) NOT NULL,
    text character varying(255),
    offer_id character varying(36),
    product_id character varying(36),
    received_user character varying(36) NOT NULL,
    send_user character varying(36) NOT NULL
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id character varying(36) NOT NULL,
    date timestamp(6) without time zone NOT NULL,
    offer_target character varying(255),
    product_target character varying(255),
    read boolean NOT NULL,
    review_target character varying(255),
    text character varying(255),
    type character varying(255) NOT NULL,
    user_target character varying(255),
    receiver_id character varying(36)
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: offers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offers (
    id character varying(36) NOT NULL,
    currency character varying(255),
    price double precision,
    creation_date timestamp(6) without time zone,
    state character varying(255),
    user_id character varying(36) NOT NULL,
    product_id character varying(36) NOT NULL
);


ALTER TABLE public.offers OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id character varying(36) NOT NULL,
    order_create_date timestamp(6) without time zone NOT NULL,
    order_update_date timestamp(6) without time zone NOT NULL,
    state character varying(255) NOT NULL,
    order_delivery character varying(36),
    delivery_address character varying(36) NOT NULL,
    order_offer character varying(36),
    order_product character varying(36) NOT NULL,
    order_transaction character varying(36),
    order_user character varying(36) NOT NULL
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_methods (
    id character varying(36) NOT NULL,
    credit_card character varying(255) NOT NULL,
    expiry_date date NOT NULL,
    is_default boolean NOT NULL,
    owner character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.payment_methods OWNER TO postgres;

--
-- Name: product_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_category (
    id character varying(36) NOT NULL,
    primary_cat character varying(255) NOT NULL,
    secondary_cat character varying(255) NOT NULL,
    tertiary_cat character varying(255) NOT NULL,
    visibility character varying(255)
);


ALTER TABLE public.product_category OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id character varying(36) NOT NULL,
    availability character varying(255) NOT NULL,
    brand character varying(255),
    condition character varying(255) NOT NULL,
    delivery_currency character varying(255) NOT NULL,
    delivery_price double precision NOT NULL,
    description character varying(1000),
    last_update_date timestamp(6) without time zone NOT NULL,
    like_number integer NOT NULL,
    product_currency character varying(255) NOT NULL,
    product_price double precision NOT NULL,
    delivery_type character varying(255),
    title character varying(100) NOT NULL,
    upload_date timestamp(6) without time zone NOT NULL,
    views integer NOT NULL,
    visibility character varying(255) NOT NULL,
    category_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products_image (
    id character varying(36) NOT NULL,
    description character varying(255),
    url_photo character varying(255) NOT NULL,
    product_id character varying(36) NOT NULL
);


ALTER TABLE public.products_image OWNER TO postgres;

--
-- Name: report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.report (
    id character varying(36) NOT NULL,
    date timestamp(6) without time zone NOT NULL,
    description character varying(255) NOT NULL,
    last_update timestamp(6) without time zone NOT NULL,
    status character varying(255) NOT NULL,
    admin character varying(36),
    reported_product_id character varying(36),
    reported_user_id character varying(36) NOT NULL,
    reporter_id character varying(36) NOT NULL
);


ALTER TABLE public.report OWNER TO postgres;

--
-- Name: review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review (
    id character varying(36) NOT NULL,
    date timestamp(6) without time zone NOT NULL,
    description character varying(255),
    title character varying(255),
    vote integer NOT NULL,
    reviewed character varying(36) NOT NULL,
    reviewer character varying(36) NOT NULL
);


ALTER TABLE public.review OWNER TO postgres;

--
-- Name: size; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.size (
    id character varying(36) NOT NULL,
    size_name character varying(255) NOT NULL,
    type character varying(255) NOT NULL
);


ALTER TABLE public.size OWNER TO postgres;

--
-- Name: transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transaction (
    id character varying(36) NOT NULL,
    currency character varying(255),
    price double precision,
    creation_date timestamp(6) without time zone NOT NULL,
    payment_method character varying(255) NOT NULL,
    payment_method_owner character varying(255) NOT NULL,
    transaction_state character varying(255) NOT NULL
);


ALTER TABLE public.transaction OWNER TO postgres;

--
-- Name: user_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_image (
    id character varying(36) NOT NULL,
    description character varying(255),
    url_photo character varying(255) NOT NULL,
    user_id character varying(36)
);


ALTER TABLE public.user_image OWNER TO postgres;

--
-- Name: user_likes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_likes (
    product_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_likes OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying(36) NOT NULL,
    bio character varying(500),
    email character varying(100) NOT NULL,
    email_verified boolean NOT NULL,
    followers_number integer NOT NULL,
    following_number integer NOT NULL,
    password character varying(255) NOT NULL,
    provider character varying(255) NOT NULL,
    reviews_number integer NOT NULL,
    reviews_total_sum integer NOT NULL,
    role character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    username character varying(255) NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: clothing; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3470.dat

--
-- Data for Name: delivery; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3471.dat

--
-- Data for Name: delivery_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3472.dat

--
-- Data for Name: entertainment; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3473.dat

--
-- Data for Name: followers_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3474.dat

--
-- Data for Name: home; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3475.dat

--
-- Data for Name: invalid_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3476.dat

--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3477.dat

--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3478.dat

--
-- Data for Name: offers; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3479.dat

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3480.dat

--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3481.dat

--
-- Data for Name: product_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3482.dat

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3483.dat

--
-- Data for Name: products_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3484.dat

--
-- Data for Name: report; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3485.dat

--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3486.dat

--
-- Data for Name: size; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3487.dat

--
-- Data for Name: transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3488.dat

--
-- Data for Name: user_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3489.dat

--
-- Data for Name: user_likes; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3490.dat

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3491.dat

--
-- Name: clothing clothing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clothing
    ADD CONSTRAINT clothing_pkey PRIMARY KEY (product_id);


--
-- Name: delivery_address delivery_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_address
    ADD CONSTRAINT delivery_address_pkey PRIMARY KEY (id);


--
-- Name: delivery delivery_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery
    ADD CONSTRAINT delivery_pkey PRIMARY KEY (id);


--
-- Name: entertainment entertainment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entertainment
    ADD CONSTRAINT entertainment_pkey PRIMARY KEY (product_id);


--
-- Name: followers_list followers_list_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.followers_list
    ADD CONSTRAINT followers_list_pkey PRIMARY KEY (id);


--
-- Name: home home_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home
    ADD CONSTRAINT home_pkey PRIMARY KEY (product_id);


--
-- Name: invalid_tokens invalid_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invalid_tokens
    ADD CONSTRAINT invalid_tokens_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: offers offers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT offers_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: product_category product_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_category
    ADD CONSTRAINT product_category_pkey PRIMARY KEY (id);


--
-- Name: products_image products_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_image
    ADD CONSTRAINT products_image_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: report report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT report_pkey PRIMARY KEY (id);


--
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (id);


--
-- Name: size size_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.size
    ADD CONSTRAINT size_pkey PRIMARY KEY (id);


--
-- Name: transaction transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_pkey PRIMARY KEY (id);


--
-- Name: users uk_6dotkott2kjsp8vw4d0m25fb7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_6dotkott2kjsp8vw4d0m25fb7 UNIQUE (email);


--
-- Name: invalid_tokens uk_h0hdg4n874r0ojrsf6t3duln5; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invalid_tokens
    ADD CONSTRAINT uk_h0hdg4n874r0ojrsf6t3duln5 UNIQUE (token);


--
-- Name: users uk_r43af9ap4edm43mmtq01oddj6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_r43af9ap4edm43mmtq01oddj6 UNIQUE (username);


--
-- Name: user_image user_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_image
    ADD CONSTRAINT user_image_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: orders fk16qm22m9umcv9eoslhadcfu4b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk16qm22m9umcv9eoslhadcfu4b FOREIGN KEY (order_user) REFERENCES public.users(id);


--
-- Name: products fk1bfbbw5vei53vhmynbdfxq50n; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk1bfbbw5vei53vhmynbdfxq50n FOREIGN KEY (category_id) REFERENCES public.product_category(id);


--
-- Name: home fk1oidjc6qmnt5w3agwfgnnotmk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home
    ADD CONSTRAINT fk1oidjc6qmnt5w3agwfgnnotmk FOREIGN KEY (size) REFERENCES public.size(id);


--
-- Name: messages fk2ewpjjb1xjcy1jaq11i3m6miy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk2ewpjjb1xjcy1jaq11i3m6miy FOREIGN KEY (send_user) REFERENCES public.users(id);


--
-- Name: report fk2fm8nu7yscahr6sbhhgw082mp; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fk2fm8nu7yscahr6sbhhgw082mp FOREIGN KEY (reported_user_id) REFERENCES public.users(id);


--
-- Name: messages fk2jhfkv8qivbav4bjrgcljlbnq; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk2jhfkv8qivbav4bjrgcljlbnq FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: delivery fk30flbmdoirxgfet0ec69cqap7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery
    ADD CONSTRAINT fk30flbmdoirxgfet0ec69cqap7 FOREIGN KEY (receiver_address) REFERENCES public.delivery_address(id);


--
-- Name: messages fk3npva4kr58ny20hani0e0o72e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk3npva4kr58ny20hani0e0o72e FOREIGN KEY (offer_id) REFERENCES public.offers(id);


--
-- Name: orders fk52ysaqbdp9viagkyh1gq6hv14; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk52ysaqbdp9viagkyh1gq6hv14 FOREIGN KEY (order_delivery) REFERENCES public.delivery(id);


--
-- Name: user_likes fk6aog39hkl1hs1amxef5i9g4fv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_likes
    ADD CONSTRAINT fk6aog39hkl1hs1amxef5i9g4fv FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: messages fk8ynxst596agpovudjo7qf3yah; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk8ynxst596agpovudjo7qf3yah FOREIGN KEY (received_user) REFERENCES public.users(id);


--
-- Name: notifications fk9kxl0whvhifo6gw4tjq36v53k; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk9kxl0whvhifo6gw4tjq36v53k FOREIGN KEY (receiver_id) REFERENCES public.users(id);


--
-- Name: orders fk9mdodfqgkm4nkxi7gw4wxdce5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk9mdodfqgkm4nkxi7gw4wxdce5 FOREIGN KEY (delivery_address) REFERENCES public.delivery_address(id);


--
-- Name: followers_list fk9wapiyy0qb0hl4ugfdnyn8jva; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.followers_list
    ADD CONSTRAINT fk9wapiyy0qb0hl4ugfdnyn8jva FOREIGN KEY (following) REFERENCES public.users(id);


--
-- Name: offers fk9yilcimbeupq2lyrqr1nlrjyb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT fk9yilcimbeupq2lyrqr1nlrjyb FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: entertainment fkayqw0d38t0p7dftkswig78kje; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entertainment
    ADD CONSTRAINT fkayqw0d38t0p7dftkswig78kje FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: delivery fkbr7r4a0spwvu4nqsdvlykb4ih; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery
    ADD CONSTRAINT fkbr7r4a0spwvu4nqsdvlykb4ih FOREIGN KEY (sender_address) REFERENCES public.delivery_address(id);


--
-- Name: clothing fkbxahoifn9ymf19jdf3ly5dxyj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clothing
    ADD CONSTRAINT fkbxahoifn9ymf19jdf3ly5dxyj FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: products fkdb050tk37qryv15hd932626th; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fkdb050tk37qryv15hd932626th FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: review fkgbajd0i5439r6xytwib2ksv56; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT fkgbajd0i5439r6xytwib2ksv56 FOREIGN KEY (reviewed) REFERENCES public.users(id);


--
-- Name: review fkgsuk8npq49gkmfmc47b9nnjec; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT fkgsuk8npq49gkmfmc47b9nnjec FOREIGN KEY (reviewer) REFERENCES public.users(id);


--
-- Name: payment_methods fkin7rtmim3ljrrhh5kxbq27s2v; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT fkin7rtmim3ljrrhh5kxbq27s2v FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: report fkisge8jdrl7ara0kwx2obnle49; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fkisge8jdrl7ara0kwx2obnle49 FOREIGN KEY (admin) REFERENCES public.users(id);


--
-- Name: offers fkjf1jh3h4v4m7diel8vvhmuqas; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offers
    ADD CONSTRAINT fkjf1jh3h4v4m7diel8vvhmuqas FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: clothing fkjtmxyrxthqaadjemwhdp607pc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clothing
    ADD CONSTRAINT fkjtmxyrxthqaadjemwhdp607pc FOREIGN KEY (size) REFERENCES public.size(id);


--
-- Name: orders fkl8u9432sit96o0btgv7vwn8f6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fkl8u9432sit96o0btgv7vwn8f6 FOREIGN KEY (order_product) REFERENCES public.products(id);


--
-- Name: user_image fko80y1v1f5vsfflp3jlax0x1c6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_image
    ADD CONSTRAINT fko80y1v1f5vsfflp3jlax0x1c6 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: delivery_address fkosi22w3gpb8k8ts839ayo7p35; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivery_address
    ADD CONSTRAINT fkosi22w3gpb8k8ts839ayo7p35 FOREIGN KEY (owner_address) REFERENCES public.users(id);


--
-- Name: report fkpotjcjhn49d2qs0g4n20jg221; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fkpotjcjhn49d2qs0g4n20jg221 FOREIGN KEY (reported_product_id) REFERENCES public.products(id);


--
-- Name: orders fkq2jlqyboisdd9fbq8iro8jgo3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fkq2jlqyboisdd9fbq8iro8jgo3 FOREIGN KEY (order_offer) REFERENCES public.offers(id);


--
-- Name: report fkqbhdxqd3ly7fkhly5nrl2j93k; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.report
    ADD CONSTRAINT fkqbhdxqd3ly7fkhly5nrl2j93k FOREIGN KEY (reporter_id) REFERENCES public.users(id);


--
-- Name: orders fkr1o78bys6wecn4cncih1eikh9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fkr1o78bys6wecn4cncih1eikh9 FOREIGN KEY (order_transaction) REFERENCES public.transaction(id);


--
-- Name: home fksbpypu2224jwkvmay08ffn9un; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home
    ADD CONSTRAINT fksbpypu2224jwkvmay08ffn9un FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: products_image fksly8833rax50pyabfssnjvn87; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_image
    ADD CONSTRAINT fksly8833rax50pyabfssnjvn87 FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: followers_list fkt0jaing4ebq2k6wqy7yc2ihjh; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.followers_list
    ADD CONSTRAINT fkt0jaing4ebq2k6wqy7yc2ihjh FOREIGN KEY (follower) REFERENCES public.users(id);


--
-- Name: user_likes fktopf6hqglo23pjf3pc53qo54m; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_likes
    ADD CONSTRAINT fktopf6hqglo23pjf3pc53qo54m FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- PostgreSQL database dump complete
--

